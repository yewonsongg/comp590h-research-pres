/* All diagrams and content are editable. No runtime dependencies or network requests. */
const SOURCES = {
  survey: { short: 'Wei et al. · Survey §6.5, pp. 57–64', url: 'https://arxiv.org/pdf/2601.12538v2' },
  awm: { short: 'Wang et al. · Agent Workflow Memory (2024)', url: 'https://arxiv.org/html/2409.07429v1' },
  lab: { short: 'Schmidgall et al. · Agent Laboratory (2025)', url: 'https://arxiv.org/html/2501.04227v2' },
  webvoyager: { short: 'He et al. · WebVoyager (ACL 2024)', url: 'https://arxiv.org/html/2401.13919v4' }
};
const arrowDefs = `<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto-start-reverse"><path d="M0 0 8 4 0 8" fill="none" stroke="#8b9f8b" stroke-width="1.2"/></marker></defs>`;
function loopDiagram(id, labels, compact=false) {
  const w=compact?900:1440, nodeW=compact?145:240, gap=compact?35:48, y=compact?70:40, h=84;
  const nodes=labels.map((label,i)=>{const x=8+i*(nodeW+gap),cx=x+nodeW/2;const text=compact&&i===4?`<tspan x="${cx}" y="${y+34}">Improved</tspan><tspan x="${cx}" y="${y+60}">attempt</tspan>`:label;return `<g class="diagram-node" data-node="${i}"><rect x="${x}" y="${y}" width="${nodeW}" height="${h}" rx="8"/><text class="svg-label" x="${cx}" y="${y+49}" text-anchor="middle" style="font-size:${compact?20:25}px">${text}</text></g>`}).join('');
  const lines=labels.slice(1).map((_,i)=>{const x=8+i*(nodeW+gap)+nodeW;return `<path class="flow-line" data-edge="${i+1}" d="M${x+4} ${y+h/2}H${x+gap-9}" marker-end="url(#arrow-${id})"/><circle class="signal" data-signal="${i+1}" r="5" style="offset-path:path('M${x+2} ${y+h/2}H${x+gap-5}')"/>`}).join('');
  const endX=8+4*(nodeW+gap)+nodeW/2, planX=8+(compact?0:1)*(nodeW+gap)+nodeW/2;
  return `<svg id="${id}" class="${compact?'memory-loop':'loop-svg'}" viewBox="0 0 ${w} ${compact?290:255}" role="img" aria-label="${labels.join(' to ')}; feedback returns to ${compact?'the next attempt':'planning'}.">${arrowDefs.replace('id="arrow"',`id="arrow-${id}"`)}${lines}<path class="flow-line" data-edge="4" d="M${endX} ${y+h+4}V${y+h+65}H${planX}V${y+h+5}" marker-end="url(#arrow-${id})"/><text class="return-label" x="${(endX+planX)/2}" y="${y+h+99}" text-anchor="middle">${compact?'Store what worked. Reuse it when the task changes.':'Environmental feedback changes the next decision.'}</text>${nodes}</svg>`;
}
function capabilityWorkbench(){
  return `<svg class="capability-workbench" viewBox="0 0 650 490" role="img" aria-labelledby="workbench-title workbench-description">
    <title id="workbench-title">A research workbench: acting, learning, and collaborating</title>
    <desc id="workbench-description">Three complementary capabilities around one research goal: use tools and check observations, keep a reusable workflow from experience, and combine research, execution, and review in a shared report.</desc>
    <g class="workbench-lane" style="--lane:0">
      <rect class="workbench-paper" x="8" y="15" width="634" height="138" rx="5"/>
      <path d="M8 20V148" stroke="#29685e" stroke-width="4"/>
      <text class="workbench-number" x="28" y="46">01 / FOUNDATIONAL</text>
      <text class="workbench-heading" x="28" y="84">Act on the task.</text>
      <text class="workbench-caption" x="28" y="115">Tools + observations</text>
      <rect x="340" y="33" width="248" height="77" rx="4" fill="#f7f7ef" stroke="#829e8b" stroke-width="1.5"/>
      <path d="M340 51H588" stroke="#b5c5b1"/>
      <path d="M350 42H357M362 42H369M374 42H381" stroke="#829e8b" stroke-width="3"/>
      <path d="M357 66H418M357 77H446M357 88H401" stroke="#b5c5b1" stroke-width="3"/>
      <rect x="486" y="66" width="82" height="27" rx="3" fill="#29685e"/>
      <text x="527" y="84" text-anchor="middle" font-size="13" style="fill:#f5f2e9">USE TOOL</text>
      <path d="m535 84 19 13-10 2-5 9Z" fill="#ae654b" stroke="#f5f2e9" stroke-width="1.5"/>
      <path d="M575 113V130H355M362 124l-7 6 7 6" fill="none" stroke="#829e8b" stroke-width="1.5"/>
      <rect x="402" y="119" width="135" height="20" fill="#edf1e7"/>
      <text x="469" y="133" text-anchor="middle" font-size="12" style="fill:#526d5f">inspect what changed</text>
    </g>
    <g class="workbench-lane" style="--lane:1">
      <rect class="workbench-paper" x="8" y="170" width="634" height="138" rx="5"/>
      <path d="M8 175V303" stroke="#ae654b" stroke-width="4"/>
      <text class="workbench-number" x="28" y="201">02 / SELF-EVOLVING</text>
      <text class="workbench-heading" x="28" y="239">Learn the lesson.</text>
      <text class="workbench-caption" x="28" y="270">Experience → workflow</text>
      <path d="M343 197H367M343 208H379M343 219H365M343 230H375" stroke="#b39c89" stroke-width="2.5"/>
      <text x="358" y="252" text-anchor="middle" font-size="12" style="fill:#8b6957">trace</text>
      <path d="M394 222H421m-7-6 7 6-7 6" fill="none" stroke="#ae654b" stroke-width="1.5"/>
      <rect x="446" y="191" width="151" height="96" rx="3" fill="#e9e4d8" stroke="#d4cabb"/>
      <rect x="437" y="185" width="151" height="96" rx="3" fill="#f8f5ed" stroke="#b6a693" stroke-width="1.5"/>
      <path d="M451 185V281" stroke="#dfb9a5"/>
      <text x="465" y="207" font-size="12" letter-spacing="1" style="fill:#ae654b">WORKFLOW</text>
      <text x="465" y="230" font-size="14">Search</text>
      <text x="465" y="248" font-size="14">Inspect</text>
      <text x="465" y="266" font-size="14">Verify & reuse</text>
    </g>
    <g class="workbench-lane" style="--lane:2">
      <rect class="workbench-paper" x="8" y="325" width="634" height="138" rx="5"/>
      <path d="M8 330V458" stroke="#638495" stroke-width="4"/>
      <text class="workbench-number" x="28" y="356">03 / COLLECTIVE</text>
      <text class="workbench-heading" x="28" y="394">Build a shared result.</text>
      <text class="workbench-caption" x="28" y="425">Specialists + review</text>
      <g fill="#f8f7ef" stroke="#9bafba" stroke-width="1.5">
        <path d="M341 344h65v57h-65z"/>
        <path d="M425 344h65v57h-65z"/>
        <path d="M509 344h79v57h-79z"/>
      </g>
      <path d="M353 357H392M353 365H384M353 373H390" stroke="#a8b9bd" stroke-width="2"/>
      <text x="457" y="369" text-anchor="middle" font-family="monospace" font-size="21" style="fill:#638495">&lt;/&gt;</text>
      <path d="m531 364 10 9 17-19" fill="none" stroke="#638495" stroke-width="2.5"/>
      <text x="373" y="391" text-anchor="middle" font-size="11">Research</text>
      <text x="457" y="391" text-anchor="middle" font-size="11">Execute</text>
      <text x="548" y="391" text-anchor="middle" font-size="11">Review</text>
      <path d="M345 414H584" stroke="#a8b9bd" stroke-width="1.5"/>
      <rect x="341" y="425" width="247" height="23" rx="2" fill="#e1e8e8"/>
      <text x="464" y="441" text-anchor="middle" font-size="12" style="fill:#426475">One report, supported by evidence</text>
    </g>
    <text x="325" y="486" text-anchor="middle" class="workbench-footnote">Complementary capabilities, combined around one goal.</text>
  </svg>`;
}
function network(id){
  const roles=[{x:155,y:90,role:'Navigator',task:'Find candidate sources'},{x:735,y:90,role:'Extractor',task:'Return supporting passages'},{x:155,y:340,role:'Aggregator',task:'Draft evidence-based answer'},{x:735,y:340,role:'Feedback loop',task:'Send evidence gaps back'}];
  return `<svg id="${id}" class="network-svg" viewBox="0 0 900 440" role="img" aria-label="INFOGENT assigns navigation, extraction, and aggregation roles. The aggregation stage sends evidence gaps back to navigation.">${roles.map((r,i)=>`<path class="flow-line" data-edge="${i+1}" d="M450 215L${r.x} ${r.y}"/><circle class="signal" data-signal="${i+1}" r="6" style="offset-path:path('M450 215L${r.x} ${r.y}')"/>`).join('')}${roles.map((r,i)=>`<g class="diagram-node" data-node="${i+1}"><rect x="${r.x-128}" y="${r.y-42}" width="256" height="84" rx="7"/><text class="role" x="${r.x}" y="${r.y-1}" text-anchor="middle">${r.role}</text><text class="task" x="${r.x}" y="${r.y+27}" text-anchor="middle">${r.task}</text></g>`).join('')}<g class="diagram-node coord" data-node="0"><circle cx="450" cy="215" r="83"/><text class="role" x="450" y="210" text-anchor="middle">Web question</text><text x="450" y="240" text-anchor="middle" style="font-size:16px">Evidence needed?</text></g><text class="svg-caption" x="450" y="432" text-anchor="middle">Specific evidence moves forward. Missing evidence moves back.</text></svg>`;
}
const SLIDES = [
{
  title:'Agentic reasoning', chapter:'Introduction', seconds:35, steps:0, source:'survey', sourceDetail:'Yewon and Lucas',
  html:`<div class="eyebrow landing-eyebrow">COMP 590H <span class="sep">/</span> A SURVEY FOR AGENTIC REASONING FOR LLMs</div><div class="hero-layout"><div class="hero-copy"><span class="landing-accent" aria-hidden="true"></span><h1>Agentic<br><em>reasoning.</em></h1><p class="subtitle">From interacting with the world<br>to improving how we work together.</p><div class="hero-line"><span class="hero-chapter"><small>01</small> Acting</span><span class="hero-connector" aria-hidden="true">→</span><span class="hero-chapter"><small>02</small> Learning</span><span class="hero-connector" aria-hidden="true">→</span><span class="hero-chapter"><small>03</small> Collaborating</span></div></div><div class="hero-figure"><div class="hero-figure-label"><span>A RESEARCH WORKBENCH</span><span>§ 6.5</span></div>${capabilityWorkbench()}</div></div><div class="hero-bottom"><span class="pill">Section 6.5</span><span>Autonomous Web Exploration & Research Agents</span></div>`,
  notesFormat:'markdown',
 notes:[
   "Main idea: Introduce the topic and presentation structure.",
   "- Section 6.5 focuses on autonomous web exploration and research agents.\n- Main question: How can LLMs go beyond generating responses to acting, learning, and collaborating?\n- Three main sections:\n  - Foundational reasoning: Acting and completing tasks.\n  - Self-evolving reasoning: Learning from feedback and experience.\n  - Collective reasoning: Multiple agents coordinating to complete tasks."
 ]
},
{
 title:'Three capabilities. One growing system.',chapter:'Introduction',seconds:30,steps:2,source:'survey',sourceDetail:'§6.5.1–6.5.3 · Capabilities can be combined',
 html:`<div class="slide-head"><span class="eyebrow">THE ARGUMENT <span class="sep">/</span> THREE COMPLEMENTARY DIMENSIONS</span><h2>Three capabilities.<br>One growing system.</h2></div><div class="roadmap"><div class="roadmap-item"><span class="roman">01</span><h3>Acting</h3><p>Turn goals into actions.<br>Check what changed.</p><span class="label">Foundational reasoning</span></div><div class="roadmap-item reveal" data-reveal="1"><span class="roman">02</span><h3>Learning</h3><p>Turn experience into<br>reusable guidance.</p><span class="label">Self-evolving reasoning</span></div><div class="roadmap-item reveal" data-reveal="2"><span class="roman">03</span><h3>Collaborating</h3><p>Turn specialized work<br>into a shared result.</p><span class="label">Collective reasoning</span></div></div>`,
 notesFormat:'markdown',
 notes:[
   "Main idea: Explain how the three types of reasoning connect.",
   "- Foundational: Planning, tool use, search and retrieval.\n- Self-evolving: Adding memory, feedback, and reflection to improve future performance.\n- Collective: Specialized agents working together toward a shared goal.\n- These aren't mutually exclusive. One agentic system can incorporate all three.",
   "Transition: Before agents can learn or collaborate, they first need the ability to act."
 ]
},
{
 title:'From responses to real-world tasks.',chapter:'01 · Acting',seconds:90,steps:2,source:'survey',sourceDetail:'§6.5.1 · Planning, tool use, and search and retrieval · Illustrative flight search',
 html:`<div class="slide-head"><span class="eyebrow">§ 6.5.1 <span class="sep">/</span> FOUNDATIONAL AGENTIC REASONING</span><h2>From responses to <em>real-world tasks.</em></h2><p class="dek">Find a nonstop Raleigh-to-Boston flight under $300 on your chosen date.</p></div><div class="foundation-contrast"><div class="foundation-response"><span class="label">Traditional LLM</span><h3>Suggest a flight.</h3><p>Respond using the information<br>it is given.</p></div><span class="foundation-shift reveal" data-reveal="1" aria-hidden="true">→</span><div class="foundation-agent reveal" data-reveal="1"><span class="label">Agentic flight search</span><div class="research-actions" aria-label="Search the route and date, filter nonstop, check fare details and availability, and return matching options"><div><span class="research-action-index">01</span><p>Search<br>route & date</p></div><div><span class="research-action-index">02</span><p>Filter<br>nonstop</p></div><div><span class="research-action-index">03</span><p>Check<br>fare details</p></div><div><span class="research-action-index">04</span><p>Return<br>options</p></div></div></div></div><div class="foundation-band reveal" data-reveal="2"><span class="label">Three foundational capabilities make this possible</span><div class="foundation-capabilities"><div><span class="foundation-capability-number">01</span><h3>Planning</h3><p>Choose the search steps<br>and travel constraints.</p></div><div><span class="foundation-capability-number">02</span><h3>Tool use</h3><p>Enter details and apply<br>filters in a browser.</p></div><div><span class="foundation-capability-number">03</span><h3>Search & retrieval</h3><p>Find flights and retrieve<br>current fare details.</p></div></div><p class="foundation-takeaway">Together, these capabilities connect <em>reasoning to execution.</em></p></div>`,
 notesFormat:'markdown',
 notes:[
   "Main idea: Explain the purpose of Section 6.5.1.",
   "- Traditional LLMs primarily generate responses based on their knowledge and input.\n- Agentic systems can interact with external environments and execute multi-step tasks.\n- Example: Finding a nonstop flight from Raleigh to Boston under $300.\n  - Traditional LLM: Might suggest flights based on available knowledge.\n  - Web agent: Searches flights, applies filters, and verifies prices and availability.",
   "Three foundational capabilities:",
   "1. Planning: Break the goal into smaller steps.\n2. Tool use: Execute actions using browsers or software.\n3. Search and retrieval: Find relevant, current information.",
   "Key point: These capabilities work together, allowing agents to go from knowing what to do to actually doing it."
 ]
},
{
 title:'Reasoning becomes a feedback loop.',chapter:'01 · Acting',seconds:95,steps:4,kind:'reasoning',source:'survey',sourceDetail:'§6.5.1 · Illustrative task; no live agent is running',
 html:`<div class="slide-head"><span class="eyebrow">01 <span class="sep">/</span> FOUNDATIONAL AGENTIC REASONING</span><h2>Reasoning becomes a <em>feedback loop.</em></h2><p class="dek">Find a nonstop flight from Raleigh to Boston under $300.</p></div>${loopDiagram('reasoning-loop',['Goal','Plan','Tool action','Observation','Updated plan'])}<div class="stage-reading"><span class="stage-num" data-stage-number>01</span><div><p class="active-message" data-message></p><p class="stage-caption" data-stage-caption></p></div></div><div class="diagram-controls"><button data-advance>Advance loop →</button><button data-replay>↺ Replay</button><span class="caption">Illustrative flight search · no live fares</span></div>`,
 messages:[
   ['Find a flight that meets the travel requirements.','Raleigh → Boston · your chosen date · nonstop · under $300.'],
   ['Enter route and date → filter nonstop → compare fares.','Break the goal into a few concrete steps.'],
   ['Open a promising flight’s fare details.','Use the browser to check the price and availability.'],
   ['The selected fare is no longer available.','The search result does not guarantee an available fare.'],
   ['Refresh the results and check another nonstop option.','Keep the same date, route, and budget.']
 ],
 notesFormat:'markdown',
 notes:[
   "Main idea: Agents must adjust based on what happens after taking action.",
   "Use the same flight-search example:",
   "- Plan: Search flights for the specified date, route, and budget.\n- Act: Open a promising flight using the browser.\n- Observe: The advertised fare is no longer available.\n- Adjust: Search for another nonstop flight meeting the original requirements.",
   "Key point: Agents don't just execute a fixed set of instructions. They continuously observe their environment and modify their plans when necessary."
 ]
},
{
 title:'Same loop. Different environments.',chapter:'01 · Acting',seconds:70,steps:2,source:'survey',sourceDetail:'§6.5.1 · Selected examples, not a ranking of systems',
 html:`<div class="slide-head"><span class="eyebrow">WHERE AGENTS ACT</span><h2>Same loop. Different environments.</h2><p class="dek">Planning, tool use, and retrieval connect all three.</p></div><div class="tri-col slide-body"><div class="domain-card"><svg class="domain-icon" viewBox="0 0 400 130" aria-hidden="true"><rect x="55" y="8" width="285" height="112" rx="6" fill="none" stroke="#29685e" stroke-width="2"/><path d="M55 35H340M75 59H228M75 78H299M75 98H187" stroke="#a7b99a" stroke-width="3"/><circle cx="72" cy="22" r="3" fill="#ae654b"/></svg><h3>Web agents</h3><p class="domain-task">Find and cross-check<br>dynamic evidence.</p><p class="caption">Search, navigate, extract.<br>Page state changes.</p><p class="example">WebVoyager · WebThinker</p></div><div class="domain-card reveal" data-reveal="1"><svg class="domain-icon" viewBox="0 0 400 130" aria-hidden="true"><rect x="65" y="8" width="265" height="112" rx="6" fill="none" stroke="#638495" stroke-width="2"/><rect x="85" y="27" width="75" height="74" fill="#dce4e5"/><path d="M180 33H305M180 52H277" stroke="#638495" stroke-width="3"/><rect x="220" y="74" width="85" height="27" fill="#638495"/><path d="m262 86 23 13-12 4-3 13Z" fill="#ae654b"/></svg><h3>GUI agents</h3><p class="domain-task">Operate software<br>through its interface.</p><p class="caption">Perceive, locate, click, type.<br>Ground intent in pixels.</p><p class="example">Agent S · OS-Copilot</p></div><div class="domain-card reveal" data-reveal="2"><svg class="domain-icon" viewBox="0 0 400 130" aria-hidden="true"><path d="M65 35h70v60H65zM265 35h70v60h-70zM135 65h130" fill="none" stroke="#ae654b" stroke-width="2"/><circle cx="200" cy="65" r="31" fill="#eee1d6" stroke="#ae654b"/><path d="m186 65 10 10 21-23" fill="none" stroke="#ae654b" stroke-width="3"/></svg><h3>Research agents</h3><p class="domain-task">Orchestrate an inquiry<br>from idea to report.</p><p class="caption">Retrieve, experiment, interpret.<br>Preserve evidence and code.</p><p class="example">Agent Laboratory · Dolphin</p></div></div>`,
 notesFormat:'markdown',
 notes:[
   "Main idea: Introduce the three categories of agents.",
   "| **Agent type** | **What it does** | **Example** |\n| --- | --- | --- |\n| Web agent | Navigates websites, retrieves information, completes browser tasks | WebVoyager |\n| GUI (graphical user interface) agent | Interacts with software interfaces by clicking, typing, etc. | SeeClick |\n| Research agent | Conducts literature reviews, experiments, and scientific analysis | Agent Laboratory |",
   "- All three use planning, tool use, and retrieval.\n- They differ primarily in their environment and goals.\n- These categories can overlap.",
   "Important concept: GUI grounding means correctly identifying which on-screen element an agent should interact with."
 ]
},
{
 title:'WebVoyager: knowing is not executing.',chapter:'01 · Acting',seconds:110,steps:2,source:'webvoyager',sourceDetail:'§3; §5, Table 1 and error analysis · Survey §6.5.1, ref. [638] · Diagram adapted for teaching',
 html:`<div class="slide-head"><span class="eyebrow">ACTING IN PRACTICE <span class="sep">/</span> WEBVOYAGER · ACL 2024</span><h2>WebVoyager: knowing is not <em>executing.</em></h2><p class="dek">Can a multimodal model complete tasks on real websites?</p></div><div class="voyager-layout"><div><svg class="voyager-diagram" viewBox="0 0 900 330" role="img" aria-labelledby="voyager-diagram-title voyager-diagram-description"><title id="voyager-diagram-title">WebVoyager’s repeated observation and action process</title><desc id="voyager-diagram-description">A browser provides an annotated screenshot and element text to a multimodal model. The model reasons and chooses a browser action. After the action, an updated webpage provides the next observation. This flight page is a teaching illustration.</desc><defs><marker id="voyager-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0 8 4 0 8" fill="none" stroke="#829e8b" stroke-width="1.2"/></marker></defs><rect x="12" y="32" width="380" height="246" rx="7" fill="#faf8f0" stroke="#a7b99a" stroke-width="2"/><path d="M12 67H392" stroke="#d5d9cd"/><text x="30" y="55" font-size="15" letter-spacing="1" style="fill:#66716a">WEBPAGE · ANNOTATED IMAGE</text><g fill="#203c34"><rect x="33" y="94" width="25" height="22" rx="2"/><rect x="33" y="146" width="25" height="22" rx="2"/></g><g font-size="15" text-anchor="middle" style="fill:#f5f2e9"><text x="45" y="110" style="fill:#f5f2e9">1</text><text x="45" y="162" style="fill:#f5f2e9">2</text></g><text x="73" y="111" font-size="20">From</text><text x="179" y="111" font-size="20">Raleigh</text><text x="73" y="163" font-size="20">To</text><text x="179" y="163" font-size="20">Boston</text><path d="M73 123H366M73 175H366" stroke="#d5d9cd"/><rect x="33" y="208" width="220" height="40" rx="3" fill="#29685e"/><text x="48" y="235" font-size="18" style="fill:#f5f2e9">[3] Search flights</text><path d="m203 231 20 13-11 3-3 12Z" fill="#ae654b" stroke="#f5f2e9"/><path d="M398 125H490" fill="none" stroke="#829e8b" stroke-width="2" marker-end="url(#voyager-arrow)"/><text x="445" y="107" text-anchor="middle" font-size="17" style="fill:#29685e">Observe</text><rect x="500" y="79" width="348" height="112" rx="6" fill="#203c34"/><text x="674" y="124" text-anchor="middle" font-family="Georgia,serif" font-size="30" style="font-family:Georgia,serif;fill:#f5f2e9">Reason → choose an action</text><text x="674" y="155" text-anchor="middle" font-size="18" style="fill:#c3d0c0">Task + image + text + history</text><path d="M674 197V241H405" fill="none" stroke="#829e8b" stroke-width="2" marker-end="url(#voyager-arrow)"/><text x="572" y="226" text-anchor="middle" font-size="20" style="fill:#29685e">Click · type · scroll</text><text x="450" y="316" text-anchor="middle" font-size="18" style="fill:#66716a">Updated screenshot → next decision · stop or reach the step limit</text></svg><div class="voyager-capabilities"><div><b>Planning</b><span>Choose the next step.</span></div><div><b>Tool use</b><span>Operate the browser.</span></div><div><b>Search & retrieval</b><span>Locate task-relevant content.</span></div></div></div><aside class="voyager-result reveal" data-reveal="1"><span class="label">Reported task success</span><div class="voyager-score">59.1<span>%</span></div><p class="voyager-sample">643 tasks · 15 real websites</p><p class="caption">GPT-4V backbone · human evaluation<br>Whole-task success, not step accuracy.</p><div class="voyager-limit"><span class="label">Execution remains fragile</span><p>Wrong targets, misread pages,<br>and getting stuck can derail a task.</p></div></aside></div><div class="voyager-insight reveal" data-reveal="2"><h3>Understanding the next step ≠ <em>carrying it out reliably.</em></h3><p>A model can choose a sensible action and still fail to execute it correctly.</p></div>`,
 notesFormat:'markdown',
 notes:[
   "Main idea: Show a real-world implementation of foundational agentic reasoning.",
   "### What is WebVoyager?",
   "- A multimodal web agent introduced in a 2024 ACL paper.\n- Designed to autonomously complete tasks on real websites.\n- Uses GPT-4V to understand screenshots and decide which browser actions to perform.\n- Demonstrates how LLM reasoning can be connected to real browser interactions.",
   "### How does WebVoyager work?",
   "1. Observe: Examine the webpage through a screenshot with numbered interactive elements.\n2. Reason: Determine what action is needed next.\n3. Act: Click, type, scroll, or navigate.\n4. Repeat: Receive an updated screenshot and continue until the task is complete.",
   "### Results and significance",
   "# 59.1%",
   "Task success rate",
   "- Evaluated on 643 tasks across 15 real websites.\n- GPT-4V-based agent achieved 59.1% whole-task success with human evaluation.\n- Demonstrates the potential of autonomous browser navigation, but also its reliability limitations.",
   "### Biggest insight from WebVoyager",
   "Understanding what to do isn't the same as successfully executing it.",
   "- An agent might have the correct plan but click the wrong button.\n- It could misinterpret a screenshot or misunderstand the current webpage.\n- Mistakes in individual actions can cause the entire task to fail.",
   "Connection to Section 6.5.1: WebVoyager demonstrates foundational reasoning through planning, browser tool use, and web information retrieval."
 ]
},
{
 title:'A plan must survive contact with the page.',chapter:'01 · Acting',seconds:65,steps:3,source:'survey',sourceDetail:'§6.5.1–6.5.2 · Illustrative failure and recovery, not a benchmark result',
 html:`<div class="slide-head"><span class="eyebrow">THE RELIABILITY PROBLEM</span><h2>A plan must survive contact<br>with the page.</h2></div><div class="failure-layout"><div class="mock-browser"><div class="browser-top"><span>Flight search · illustrative</span><span>● ● ●</span></div><div class="browser-body"><div class="fake-input">Raleigh → Boston · chosen date <span>⌕</span></div><div class="fake-result">A promising nonstop flight<span>A cookie dialog covers the “View fare” button.</span></div><div class="bad-state">Click attempted → page did not change.</div><p class="caption" style="margin-top:22px">Intent was plausible.<br>The action did not achieve its subgoal.</p></div></div><div class="recovery-steps"><div class="recovery-row reveal" data-reveal="1"><span class="num">1</span><div><h3>Detect the mismatch</h3><p>Compare the expected state with the observed page.</p></div></div><div class="recovery-row reveal" data-reveal="2"><span class="num">2</span><div><h3>Repair the local action</h3><p>Close the dialog; locate “View fare”; retry.</p></div></div><div class="recovery-row reveal" data-reveal="3"><span class="num">3</span><div><h3>Preserve the lesson</h3><p>Retain a useful recovery strategy for later tasks.</p></div></div></div><p class="bottom-thought">Long action chains amplify small errors. <em>Verification makes recovery possible.</em></p>`,
 notesFormat:'markdown',
 notes:[
   "Main idea: Explain why feedback and error recovery matter.",
   "Continue the flight-search example:",
   "- Agent attempts to select a flight, but a cookie popup blocks the button.\n- The agent must recognize that its action failed rather than assuming it succeeded.",
   "Three steps to recovery:",
   "1. Detect: Compare expected and actual outcomes.\n2. Repair: Close the popup and retry the correct action.\n3. Preserve: Store the successful recovery strategy for similar tasks.",
   "Key distinction:",
   "- Foundational reasoning allows agents to adjust during the current task.\n- Self-evolving reasoning allows agents to retain useful experiences for future tasks.",
   "Transition to Section 6.5.2: Once an agent can act and recover from errors, how can it use those experiences to improve its performance on future tasks?"
 ]
},
{
 title:'AWM turns one web task into guidance for the next.',chapter:'02 · Learning',seconds:85,steps:4,kind:'memory',source:'awm',sourceDetail:'§2.2–2.3; survey §6.5.2 · Conceptual teaching example; no measured speed or success claim',
 html:`<div class="slide-head"><span class="eyebrow">02 <span class="sep">/</span> SELF-EVOLVING AGENTIC REASONING</span><h2>AWM turns one web task into<br>guidance for the <em>next.</em></h2></div><div class="memory-layout slide-body"><div>${loopDiagram('memory-loop',['Attempt','Feedback','Reflection','Memory','Improved attempt'],true)}<div class="stage-reading"><span class="stage-num" data-stage-number>01</span><div><p class="active-message" data-message></p></div></div></div><div class="memory-panel"><span class="label">A later flight-search task</span><div class="diagram-controls" role="group" aria-label="Persistent memory comparison"><button data-memory="off" aria-pressed="false">No memory</button><button data-memory="on" aria-pressed="true" class="selected">Workflow memory</button></div><h3 data-memory-heading>Experience not yet stored.</h3><div class="memory-code" data-memory-code>Enter route and date<br>→ inspect flight results.</div><p class="memory-result" data-memory-result></p></div></div><div class="diagram-controls"><button data-advance>Advance learning loop →</button><button data-replay>↺ Replay</button><span class="caption">AWM supplies a reusable procedure. The agent still checks the current page.</span></div>`,
 messages:[['Attempt a task and record what happened.',''],['Use an outcome signal to assess the attempt.',''],['Extract a lesson that could transfer.',''],['Persist a reusable procedure outside this attempt.',''],['Recall the procedure; adapt it to the new goal.','']],
 notes:[
   'Section 6.5.2 asks what changes after a web agent finishes one task. AWM is the concrete example: it keeps an external, text-based workflow memory rather than relying only on the current prompt. This differs from retraining the model.',
   'Advance through the loop. The agent attempts a task, sees an outcome, reflects on what mattered, and stores a reusable procedure. The flight search is illustrative: a successful attempt records how to enter the route and date, apply filters, inspect fares, and confirm availability.',
   'At the memory stage, toggle No memory, then Workflow memory. Without memory, the later task rebuilds its plan. With memory, it begins with a relevant workflow. It reuses the search procedure, not an old fare: the agent must still inspect the live page.',
   'This is the distinction to remember: reflection identifies a lesson during one attempt; memory makes that lesson available later. The next slide shows how AWM converts a particular trajectory into a general procedure.'
 ]
},
{
 title:'A reusable workflow keeps the steps, not the old answer.',chapter:'02 · Learning',seconds:90,steps:3,source:'awm',sourceDetail:'§2.2–2.3; survey §6.5.2 · Flight-search workflow adapted for teaching',
 html:`<div class="slide-head"><span class="eyebrow">PAPER 01 <span class="sep">/</span> AGENT WORKFLOW MEMORY</span><h2>A reusable workflow keeps the steps,<br>not the <em>old answer.</em></h2><p class="dek">AWM turns a successful trajectory into prompt guidance for a related future task.</p></div><div class="architecture"><div class="arch-block"><span class="label">01 / A completed task</span><h3>Record the trajectory</h3><p>What the agent saw,<br>reasoned, and did.</p></div><span class="arch-arrow reveal" data-reveal="1">→</span><div class="arch-block reveal" data-reveal="1"><span class="label">02 / AWM induction</span><h3>Extract the workflow</h3><p>Replace route and date<br>with variables.</p></div><span class="arch-arrow reveal" data-reveal="2">→</span><div class="arch-block reveal" data-reveal="2"><span class="label">03 / A later task</span><h3>Guide the next action</h3><p>Add the workflow to the prompt.<br>Verify the live result.</p></div></div><div class="workflow-example reveal" data-reveal="3"><p>Past task: find a nonstop flight<br>from <b>Raleigh to Boston</b>.</p><span class="arch-arrow">→</span><code>for {route}, {date}:<br>enter → filter nonstop → verify</code></div><div class="awm-modes"><span><b>Offline:</b> build memory from training examples.</span><span><b>Online:</b> add workflows after evaluator-approved attempts.</span></div>`,
 notes:[
   'AWM addresses procedural reuse. A full browsing episode includes details that the next task does not need. Its workflow preserves the useful pattern while replacing task-specific values with variables.',
   'Advance through induction and use. AWM extracts a routine from a trajectory, then inserts that text into the prompt that produces later actions. The memory guides the model at inference time. It does not force the agent to replay an old script or require a weight update.',
   'The online variant adds memory from attempts that a model evaluator predicts were successful. That is useful, but it creates a practical risk: an incorrect evaluator can store a bad workflow.',
   'Reveal the flight workflow. This is a teaching adaptation, not an AWM experiment. The paper’s own composition case extends a place-finding workflow to retrieve a postal code. Both illustrate the same idea: use a remembered routine as a starting point, then adapt it to the current task. Transition: how much did this help in the reported experiments?'
 ]
},
{
 title:'AWM gains appear in two different kinds of task.',chapter:'02 · Learning',seconds:85,steps:2,kind:'benchmark',source:'awm',sourceDetail:'§3.1, Table 1; §3.2, Table 3 · GPT-4 · Reported rounded values',
 html:`<div class="slide-head"><span class="eyebrow">THE EVIDENCE <span class="sep">/</span> AWM BENCHMARK RESULTS</span><h2>AWM gains appear in two<br>different kinds of <em>task.</em></h2></div><div class="results-layout"><svg class="chart" viewBox="0 0 900 420" role="img" aria-label="Relative improvement: Mind2Web 24.6 percent in cross-task step success; WebArena 51.1 percent in task success. Baselines differ."><text x="0" y="27" class="axis">RELATIVE IMPROVEMENT OVER THE LISTED BASELINE (%)</text>${[0,10,20,30,40,50,60].map(n=>`<line class="gridline" x1="${80+n*11}" y1="60" x2="${80+n*11}" y2="340"/><text class="axis" x="${80+n*11}" y="370" text-anchor="middle">${n}%</text>`).join('')}<text class="metric-name" x="80" y="89">Mind2Web</text><text class="metric-desc" x="80" y="115">Can the agent complete the next web step?</text><g tabindex="0" role="button" aria-label="Mind2Web details: 36.2 to 45.1 percent step success, 24.6 percent relative improvement" data-tooltip="mind2web"><rect class="bar" data-bar="1" x="80" y="134" width="270.6" height="55" rx="2" fill="#29685e"/><text class="value reveal" data-reveal="1" x="370" y="175">+24.6%</text><title>36.2% → 45.1% step success. (45.1−36.2)/36.2 × 100 ≈ 24.6%.</title></g><text class="metric-name" x="80" y="244">WebArena</text><text class="metric-desc" x="80" y="270">Can the agent complete the whole web task?</text><g tabindex="0" role="button" aria-label="WebArena details: 23.5 to 35.5 percent task success, 51.1 percent relative improvement" data-tooltip="webarena"><rect class="bar" data-bar="2" x="80" y="288" width="562.1" height="55" rx="2" fill="#638495"/><text class="value reveal" data-reveal="2" x="660" y="329" style="fill:#638495">+51.1%</text><title>23.5% → 35.5% task success. (35.5−23.5)/23.5 × 100 ≈ 51.1%.</title></g><text class="axis" x="80" y="410">Hover, focus, or tap a bar for the original rates.</text></svg><aside class="result-aside"><h3>Read each result in context</h3><p class="reveal" data-reveal="1"><b>36.2% → 45.1%</b><br>Step success<br><span class="caption">+8.9 percentage points</span></p><p class="reveal" data-reveal="2" style="margin-top:20px"><b>23.5% → 35.5%</b><br>Whole-task success<br><span class="caption">+12.0 percentage points</span></p><p class="caption">The relative percentages use different baselines and different success definitions.</p></aside></div><div class="chart-tooltip" id="benchmark-tooltip" hidden role="status"></div>`,
 notes:[
   'The first result answers a step-level question. In the GPT-4 cross-task Mind2Web experiment, offline AWM improves step success from 36.2 percent to 45.1 percent compared with MindAct. That is 8.9 percentage points, or about 24.6 percent relative improvement.',
   'Advance for the end-to-end result. On WebArena, online AWM reaches 35.5 percent task success versus 23.5 percent for the published BrowserGym baseline. That is 12 percentage points, or about 51.1 percent relative improvement.',
   'Do not compare bar height as if both results measure the same thing. Mind2Web checks whether the agent completed a step, including the element and action. WebArena checks whether it completed the whole task. The 15 percent accessibility-tree-only BrowserGym control is a separate comparison, not the denominator here.',
   'The practical message is modest: workflow memory helped in these settings, but even the stronger end-to-end result leaves most tasks unsolved. Next, look at the other forms of self-improvement that the survey groups with memory.'
 ]
},
{
 title:'Self-evolving agents improve in more than one way.',chapter:'02 · Learning',seconds:65,steps:3,source:'survey',sourceDetail:'§6.5.2 · Representative systems: ReAP, Mobile-Agent-E, and Dolphin',
 html:`<div class="slide-head"><span class="eyebrow">OTHER EXAMPLES <span class="sep">/</span> FEEDBACK AND REFLECTION</span><h2>Self-evolving agents improve in<br>more than <em>one way.</em></h2><p class="dek">The survey groups workflow memory with reflection and outcome-driven revision.</p></div><div class="architecture"><div class="arch-block"><span class="label">WEB / ReAP</span><h3>Retrieve a past lesson</h3><p>Store a reflection after a navigation task; retrieve it when a similar task appears.</p></div><span class="arch-arrow reveal" data-reveal="1">→</span><div class="arch-block reveal" data-reveal="1"><span class="label">GUI / Mobile-Agent-E</span><h3>Write a practical tip</h3><p>An action reflector and notetaker add Tips and Shortcuts to long-term memory.</p></div><span class="arch-arrow reveal" data-reveal="2">→</span><div class="arch-block reveal" data-reveal="2"><span class="label">RESEARCH / Dolphin</span><h3>Use execution results</h3><p>Run code, inspect exceptions and outcomes, then revise the idea or implementation.</p></div></div><div class="callout reveal" data-reveal="3" style="margin-top:35px">Across all three: a later decision changes because an earlier outcome left a usable trace.</div>`,
 notes:[
   'AWM is the detailed memory example, but Section 6.5.2 is broader. The survey also treats reflections, validation signals, GUI repair, and research execution outcomes as ways to make later behavior better.',
   'ReAP stores and retrieves a reflection from a prior web-navigation task. It turns a lesson such as a successful or failed navigation strategy into prompt guidance for another task.',
   'For GUI agents, Mobile-Agent-E has an Action Reflector and a Notetaker. They evaluate executed steps and add practical Tips and Shortcuts to persistent memory. For research agents, Dolphin runs generated code, then uses exceptions and benchmark outcomes to revise its next idea or implementation.',
   'The common rule is simple: an agent has not evolved merely because it produced a critique. An earlier outcome must leave a trace that changes a later decision. Transition: collective reasoning changes who performs the work within one task.'
 ]
},
{
 title:'INFOGENT assigns three jobs to one web question.',chapter:'03 · Collaborating',seconds:65,steps:4,kind:'network',source:'survey',sourceDetail:'§6.5.3 · INFOGENT role structure simplified for teaching',
 html:`<div class="slide-head"><span class="eyebrow">03 <span class="sep">/</span> COLLECTIVE MULTI-AGENT REASONING</span><h2>INFOGENT assigns three jobs<br>to one web <em>question.</em></h2></div><div class="network-layout">${network('collaboration-network')}<div class="network-caption"><h3 data-network-title>Start with an evidence need.</h3><p class="body-copy" data-message></p><div class="callout">A useful handoff names both the artifact to return and the reason it is needed.</div><p class="caption" style="margin-top:25px">The survey also describes GUI teams that divide planning, perception, operation, reflection, and note taking.</p></div></div><div class="diagram-controls" style="margin-top:0"><button data-advance>Show next role →</button><button data-replay>↺ Replay</button><span class="caption">The final stage sends an information gap back to navigation.</span></div>`,
 messages:[['The task begins with a question that needs current, cited evidence.',''],['Navigator: locate candidate webpages and decide where to look next.',''],['Extractor: return the particular passages that support or qualify a claim.',''],['Aggregator: combine the evidence into an answer and identify what is still missing.',''],['Feedback loop: return the unresolved gap to the Navigator for another search.','']],
 notes:[
   'Section 6.5.3 shifts the question from learning across attempts to dividing work inside one attempt. INFOGENT is the clearest web example: it assigns navigation, evidence extraction, and aggregation to distinct roles.',
   'Advance through the roles. The Navigator finds pages, the Extractor returns passages, and the Aggregator writes an answer from that evidence. This division matters because a fluent summary without supporting passages is not a useful research artifact.',
   'The last stage is the important feedback path. When the Aggregator identifies an information gap, it sends the task back to navigation. The system therefore does not simply pass a document down a fixed assembly line.',
   'Other systems use different role boundaries: WebPilot separates global planning from local MCTS executors, while GUI agents often separate planning, perception, action, reflection, and note taking. More agents also add coordination cost and can repeat the same error. Transition: trace the specific artifacts in an INFOGENT-style handoff.'
 ]
},
{
 title:'A web-research team passes evidence, not just conclusions.',chapter:'03 · Collaborating',seconds:60,steps:4,source:'survey',sourceDetail:'§6.5.3 · INFOGENT-inspired teaching walkthrough, not a reported trajectory',
 html:`<div class="slide-head"><span class="eyebrow">A WORKED EXAMPLE <span class="sep">/</span> TRACE THE ARTIFACTS</span><h2>A web-research team passes evidence,<br>not just <em>conclusions.</em></h2></div><div class="handoff-layout"><div class="question-block"><span class="label">Illustrative web question</span><h3>Which methods in §6.5.2 help an agent reuse prior experience?</h3><p>The answer needs system names, mechanisms, and support from the source.</p></div><div class="handoff-list"><div class="handoff reveal" data-reveal="1"><span class="label">Navigator →</span><p>Candidate pages: AWM, ReAP, Mobile-Agent-E, and Dolphin.</p></div><div class="handoff reveal" data-reveal="2"><span class="label">Extractor →</span><p>Support: a passage describing each system’s memory or feedback mechanism.</p></div><div class="handoff reveal" data-reveal="3"><span class="label">Aggregator →</span><p>Synthesis: workflow memory, retrieved reflection, GUI tips, and execution feedback.</p></div><div class="handoff reveal" data-reveal="4"><span class="label">Gap → Navigator</span><p>Missing detail: retrieve the relevant passage before making the claim.</p></div></div></div><p class="bottom-thought">The team improves the answer by tracing each claim back to evidence.<br><em>More agents help only when their handoffs are checkable.</em></p>`,
 notes:[
   'This is an illustrative walkthrough, not a reported INFOGENT trajectory. It applies the role structure to the question we just discussed: which self-evolving systems reuse prior experience?',
   'Advance through the handoffs. The Navigator produces a search set. The Extractor supplies the particular source passages. The Aggregator can then distinguish workflow memory, retrieved reflections, GUI tips, and execution feedback without treating them as one mechanism.',
   'The final handoff is a gap report, not a vote. If the source does not support a claim, the right next action is to retrieve better evidence, not to ask another agent to restate the conclusion.',
   'This is why interfaces matter in collective reasoning: the output of one role becomes a checkable input for the next. Transition: Agent Laboratory applies the same principle to literature, experiments, and writing.'
 ]
},
{
 title:'A research assistant, organized as a lab.',chapter:'03 · Collaborating',seconds:90,steps:3,source:'lab',sourceDetail:'§3; survey §6.5.2 names it for retained research artifacts · Simplified architecture; actual workflow has additional substages',
 html:`<div class="slide-head"><span class="eyebrow">PAPER 02 <span class="sep">/</span> AGENT LABORATORY</span><h2>A research assistant,<br>organized as a <em>lab.</em></h2><p class="dek">Problem: connect literature, experiments, and reporting around a human research idea.</p></div><div class="lab-pipeline"><div class="lab-phase"><span class="tag">01 / Read</span><h3>Literature review</h3><p>Search arXiv.<br>Build a grounded starting point.</p><div class="roles">PhD student agent</div></div><span class="arch-arrow reveal" data-reveal="1">→</span><div class="lab-phase reveal" data-reveal="1"><span class="tag">02 / Test</span><h3>Experimentation</h3><p>Plan → prepare data → run code.<br>Reflect on errors and results.</p><div class="roles">PhD · Postdoc · ML engineer<br><b>mle-solver</b>: propose, execute, score, revise</div></div><span class="arch-arrow reveal" data-reveal="2">→</span><div class="lab-phase reveal" data-reveal="2"><span class="tag">03 / Explain</span><h3>Report writing</h3><p>Interpret findings.<br>Draft and refine a report.</p><div class="roles">PhD · Professor<br><b>paper-solver</b>: iterative report refinement</div></div></div><div class="human-band reveal" data-reveal="3"><span class="label">Human guidance</span><span>Research idea at entry · feedback at subtask boundaries in co-pilot mode</span></div><div class="lab-output"><span>Output / research report + code repository</span><span>Persistent artifacts connect the phases.</span></div>`,
 notes:[
   'Agent Laboratory addresses the integration problem: a promising idea requires literature, executable experiments, interpretation, and a report. It takes a human-provided idea and notes, then runs three main phases. The academic role labels name prompted agent responsibilities, not human-equivalent qualifications.',
   'Reveal experimentation. Planning and data preparation precede execution. The mle-solver proposes or edits programs, executes them, scores outcomes, reflects on errors or improvements, and retains strong candidate programs. Its score is a search signal; it is not itself proof of scientific validity.',
   'Reveal report writing. The paper-solver turns the accumulated research into a report and iteratively refines it. Code, results, and interpretation persist across phases, which is why the survey names this system under memory in Section 6.5.2. Its specialized roles make it a useful supporting example for collaboration, even though the survey does not name it in Section 6.5.3.',
   'Reveal human guidance. In co-pilot mode, a researcher can provide feedback at the end of each subtask. The paper studies different model backends and human evaluations rather than demonstrating unrestricted autonomous science. The output is a research-assistance artifact that needs inspection. Transition: the most revealing experiment asks who is judging the result.'
 ]
},
{
 title:'A convincing report can fool its reviewer.',chapter:'03 · Collaborating',seconds:80,steps:2,kind:'review',source:'lab',sourceDetail:'§4.1–4.2; Fig. 6–7 · Scores are study averages, not acceptance probabilities',
 html:`<div class="slide-head"><span class="eyebrow">THE EVALUATION GAP <span class="sep">/</span> A DEEPER LABORATORY FINDING</span><h2>A convincing report<br>can fool its <em>reviewer.</em></h2></div><div class="review-layout"><div><svg class="review-chart" viewBox="0 0 720 320" role="img" aria-label="Average overall paper review score out of ten: automated reviewers 6.1, human reviewers 3.8.">${[0,2,4,6,8,10].map(n=>`<line class="gridline" x1="70" x2="675" y1="${260-n*20}" y2="${260-n*20}" stroke="#d5d9cd"/><text class="axis" x="47" y="${267-n*20}" text-anchor="end">${n}</text>`).join('')}<text class="axis" x="70" y="25">MEAN OVERALL REVIEW SCORE / 10</text><rect class="bar" data-bar="1" x="180" y="138" width="135" height="122" fill="#638495"/><text class="score reveal" data-reveal="1" x="247" y="122" text-anchor="middle">6.1</text><rect class="bar" data-bar="1" x="445" y="184" width="135" height="76" fill="#29685e"/><text class="score reveal" data-reveal="1" x="512" y="167" text-anchor="middle">3.8</text><text class="label-svg" x="247" y="300" text-anchor="middle">Automated</text><text class="label-svg" x="512" y="300" text-anchor="middle">Human</text></svg><p class="study-scope">Autonomous study: 5 research questions × 3 model backends = 15 papers.<br>10 PhD volunteers each reviewed 3 randomly assigned papers.</p></div><div class="review-detail"><h3>Review quality is a bottleneck.</h3><p class="reveal" data-reveal="1">Automated scores exceeded human scores by <b>2.3 points</b> on average.</p><div class="callout reveal" data-reveal="2">Co-pilot reports received a higher external overall score: <b>4.38/10</b> vs. <b>3.8/10</b> for autonomous reports.</div><p class="caption reveal" data-reveal="2" style="font-size:21px;margin-top:20px">Improvements were stronger in quality and presentation than in significance or contribution. Small, task-specific study; comparisons do not isolate a causal effect.</p></div></div><p class="bottom-thought" style="font-size:28px">Useful assistance is plausible. <em>Scientific validity still needs independent checks.</em></p>`,
 notes:[
   'The autonomous evaluation generated fifteen papers: five questions using three model backends. Ten volunteer PhD students each reviewed three randomly assigned papers. These are a small set of machine-learning research tasks, so we should not generalize the scores to all science.',
   'Advance for the chart. Automated reviewers gave an average overall score of 6.1 out of ten, while human reviewers gave 3.8. A reviewer agent is therefore not automatically an independent quality guarantee. This is the main deeper insight from the paper: automating the evaluation loop can reward outputs that look better to models than to people.',
   'Advance for co-pilot results. External evaluation gave co-pilot reports 4.38 versus 3.8 for autonomous reports. The paper reports improvements concentrated in quality, soundness, clarity, and presentation; significance slightly declined and contribution barely changed. The study is not a randomized isolation of the effect of human feedback, and backend and task differences matter.',
   'The paper also documents hallucinated experiment details and failures in execution. Its cost reductions concern particular reported inference configurations, not the total cost of doing research. We have intentionally centered scientific quality rather than treating cheap report generation as discovery. Transition: combine the useful capabilities while retaining an evidence check at every layer.'
 ]
},
{
 title:'Add capabilities. Keep the evidence loop.',chapter:'Synthesis',seconds:55,steps:2,source:'survey',sourceDetail:'Synthesis of §6.5 with AWM and Agent Laboratory · “Combined” indicates a possible design, not a universal requirement',
 html:`<div class="slide-head"><span class="eyebrow">SYNTHESIS <span class="sep">/</span> ACTING → LEARNING → COLLABORATING</span><h2>Add capabilities.<br>Keep the <em>evidence loop.</em></h2></div><table class="capability-matrix"><thead><tr><th>System configuration</th><th>Act with tools</th><th>Reuse experience</th><th>Coordinate specialists</th></tr></thead><tbody><tr><td>Foundational</td><td class="check">✓ <span class="caption">Interact & verify</span></td><td class="caption">Optional extension</td><td class="caption">Optional extension</td></tr><tr class="reveal" data-reveal="1"><td>+ Self-evolving</td><td class="check">✓</td><td class="added">+ Persistent adaptation</td><td class="caption">Optional extension</td></tr><tr class="reveal" data-reveal="2"><td>+ Collective</td><td class="check">✓</td><td class="check">✓ <span class="caption">Combined here</span></td><td class="added">+ Shared, specialized work</td></tr></tbody></table><div class="tri-col" style="margin-top:35px"><p class="caption"><b style="color:var(--ink)">Acting</b><br>Verify the observed outcome.</p><p class="caption reveal" data-reveal="1"><b style="color:var(--ink)">Learning</b><br>Check the quality of what persists.</p><p class="caption reveal" data-reveal="2"><b style="color:var(--ink)">Collaborating</b><br>Audit the artifacts and the reviewer.</p></div>`,
 notes:[
   'This matrix depicts a cumulative system design, not a claim that every multi-agent system must have persistent memory. The survey dimensions can overlap. A collective system could coordinate specialists without evolving over time, and a single agent could learn reusable workflows.',
   'Advance through the additions. Tool use expands what an agent can do. Persistent adaptation changes what it can carry into the next task. Coordination changes how specialized work is distributed. The foundational loop remains useful throughout.',
   'Three takeaways follow from the evidence we examined. First, outcomes should be checked against the environment. Second, memory is only helpful when its procedures are applicable and trustworthy. Third, a reviewer must be evaluated too; agreement and fluent reports are insufficient evidence.',
   'Close by returning to the central lesson: acting, learning, and collaborating can be combined, but each depends on evidence that the system actually achieved its goal.'
 ]
}
];
