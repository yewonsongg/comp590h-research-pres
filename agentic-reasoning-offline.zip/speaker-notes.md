# Speaker notes

16 slides · planned delivery 19:30. Advance key stages with → or Space. The main deck displays “Reveal” when more teaching steps remain. Speaking times include pauses and brief interaction, and should be rehearsed with the actual presenter.

## 01. Agentic reasoning

**Introduction · 0:35 · cumulative 0:00–0:35 · 0 progressive reveals**

Main idea: Introduce the topic and presentation structure.

- Section 6.5 focuses on autonomous web exploration and research agents.
- Main question: How can LLMs go beyond generating responses to acting, learning, and collaborating?
- Three main sections:
  - Foundational reasoning: Acting and completing tasks.
  - Self-evolving reasoning: Learning from feedback and experience.
  - Collective reasoning: Multiple agents coordinating to complete tasks.

## 02. Three capabilities. One growing system.

**Introduction · 0:30 · cumulative 0:35–1:05 · 2 progressive reveals**

Main idea: Explain how the three types of reasoning connect.

- Foundational: Planning, tool use, search and retrieval.
- Self-evolving: Adding memory, feedback, and reflection to improve future performance.
- Collective: Specialized agents working together toward a shared goal.
- These aren't mutually exclusive. One agentic system can incorporate all three.

Transition: Before agents can learn or collaborate, they first need the ability to act.

## 03. From responses to real-world tasks.

**01 · Acting · 1:30 · cumulative 1:05–2:35 · 2 progressive reveals**

Main idea: Explain the purpose of Section 6.5.1.

- Traditional LLMs primarily generate responses based on their knowledge and input.
- Agentic systems can interact with external environments and execute multi-step tasks.
- Example: Finding a nonstop flight from Raleigh to Boston under $300.
  - Traditional LLM: Might suggest flights based on available knowledge.
  - Web agent: Searches flights, applies filters, and verifies prices and availability.

Three foundational capabilities:

1. Planning: Break the goal into smaller steps.
2. Tool use: Execute actions using browsers or software.
3. Search and retrieval: Find relevant, current information.

Key point: These capabilities work together, allowing agents to go from knowing what to do to actually doing it.

## 04. Reasoning becomes a feedback loop.

**01 · Acting · 1:35 · cumulative 2:35–4:10 · 4 progressive reveals**

Main idea: Agents must adjust based on what happens after taking action.

Use the same flight-search example:

- Plan: Search flights for the specified date, route, and budget.
- Act: Open a promising flight using the browser.
- Observe: The advertised fare is no longer available.
- Adjust: Search for another nonstop flight meeting the original requirements.

Key point: Agents don't just execute a fixed set of instructions. They continuously observe their environment and modify their plans when necessary.

## 05. Same loop. Different environments.

**01 · Acting · 1:10 · cumulative 4:10–5:20 · 2 progressive reveals**

Main idea: Introduce the three categories of agents.

| **Agent type** | **What it does** | **Example** |
| --- | --- | --- |
| Web agent | Navigates websites, retrieves information, completes browser tasks | WebVoyager |
| GUI (graphical user interface) agent | Interacts with software interfaces by clicking, typing, etc. | SeeClick |
| Research agent | Conducts literature reviews, experiments, and scientific analysis | Agent Laboratory |

- All three use planning, tool use, and retrieval.
- They differ primarily in their environment and goals.
- These categories can overlap.

Important concept: GUI grounding means correctly identifying which on-screen element an agent should interact with.

## 06. WebVoyager: knowing is not executing.

**01 · Acting · 1:50 · cumulative 5:20–7:10 · 2 progressive reveals**

Main idea: Show a real-world implementation of foundational agentic reasoning.

### What is WebVoyager?

- A multimodal web agent introduced in a 2024 ACL paper.
- Designed to autonomously complete tasks on real websites.
- Uses GPT-4V to understand screenshots and decide which browser actions to perform.
- Demonstrates how LLM reasoning can be connected to real browser interactions.

### How does WebVoyager work?

1. Observe: Examine the webpage through a screenshot with numbered interactive elements.
2. Reason: Determine what action is needed next.
3. Act: Click, type, scroll, or navigate.
4. Repeat: Receive an updated screenshot and continue until the task is complete.

### Results and significance

# 59.1%

Task success rate

- Evaluated on 643 tasks across 15 real websites.
- GPT-4V-based agent achieved 59.1% whole-task success with human evaluation.
- Demonstrates the potential of autonomous browser navigation, but also its reliability limitations.

### Biggest insight from WebVoyager

Understanding what to do isn't the same as successfully executing it.

- An agent might have the correct plan but click the wrong button.
- It could misinterpret a screenshot or misunderstand the current webpage.
- Mistakes in individual actions can cause the entire task to fail.

Connection to Section 6.5.1: WebVoyager demonstrates foundational reasoning through planning, browser tool use, and web information retrieval.

## 07. A plan must survive contact with the page.

**01 · Acting · 1:05 · cumulative 7:10–8:15 · 3 progressive reveals**

Main idea: Explain why feedback and error recovery matter.

Continue the flight-search example:

- Agent attempts to select a flight, but a cookie popup blocks the button.
- The agent must recognize that its action failed rather than assuming it succeeded.

Three steps to recovery:

1. Detect: Compare expected and actual outcomes.
2. Repair: Close the popup and retry the correct action.
3. Preserve: Store the successful recovery strategy for similar tasks.

Key distinction:

- Foundational reasoning allows agents to adjust during the current task.
- Self-evolving reasoning allows agents to retain useful experiences for future tasks.

Transition to Section 6.5.2: Once an agent can act and recover from errors, how can it use those experiences to improve its performance on future tasks?

## 08. AWM turns one web task into guidance for the next.

**02 · Learning · 1:25 · cumulative 8:15–9:40 · 4 progressive reveals**

Section 6.5.2 asks what changes after a web agent finishes one task. AWM is the concrete example: it keeps an external, text-based workflow memory rather than relying only on the current prompt. This differs from retraining the model.

Advance through the loop. The agent attempts a task, sees an outcome, reflects on what mattered, and stores a reusable procedure. The flight search is illustrative: a successful attempt records how to enter the route and date, apply filters, inspect fares, and confirm availability.

At the memory stage, toggle No memory, then Workflow memory. Without memory, the later task rebuilds its plan. With memory, it begins with a relevant workflow. It reuses the search procedure, not an old fare: the agent must still inspect the live page.

This is the distinction to remember: reflection identifies a lesson during one attempt; memory makes that lesson available later. The next slide shows how AWM converts a particular trajectory into a general procedure.

## 09. A reusable workflow keeps the steps, not the old answer.

**02 · Learning · 1:30 · cumulative 9:40–11:10 · 3 progressive reveals**

AWM addresses procedural reuse. A full browsing episode includes details that the next task does not need. Its workflow preserves the useful pattern while replacing task-specific values with variables.

Advance through induction and use. AWM extracts a routine from a trajectory, then inserts that text into the prompt that produces later actions. The memory guides the model at inference time. It does not force the agent to replay an old script or require a weight update.

The online variant adds memory from attempts that a model evaluator predicts were successful. That is useful, but it creates a practical risk: an incorrect evaluator can store a bad workflow.

Reveal the flight workflow. This is a teaching adaptation, not an AWM experiment. The paper’s own composition case extends a place-finding workflow to retrieve a postal code. Both illustrate the same idea: use a remembered routine as a starting point, then adapt it to the current task. Transition: how much did this help in the reported experiments?

## 10. AWM gains appear in two different kinds of task.

**02 · Learning · 1:25 · cumulative 11:10–12:35 · 2 progressive reveals**

The first result answers a step-level question. In the GPT-4 cross-task Mind2Web experiment, offline AWM improves step success from 36.2 percent to 45.1 percent compared with MindAct. That is 8.9 percentage points, or about 24.6 percent relative improvement.

Advance for the end-to-end result. On WebArena, online AWM reaches 35.5 percent task success versus 23.5 percent for the published BrowserGym baseline. That is 12 percentage points, or about 51.1 percent relative improvement.

Do not compare bar height as if both results measure the same thing. Mind2Web checks whether the agent completed a step, including the element and action. WebArena checks whether it completed the whole task. The 15 percent accessibility-tree-only BrowserGym control is a separate comparison, not the denominator here.

The practical message is modest: workflow memory helped in these settings, but even the stronger end-to-end result leaves most tasks unsolved. Next, look at the other forms of self-improvement that the survey groups with memory.

## 11. Self-evolving agents improve in more than one way.

**02 · Learning · 1:05 · cumulative 12:35–13:40 · 3 progressive reveals**

AWM is the detailed memory example, but Section 6.5.2 is broader. The survey also treats reflections, validation signals, GUI repair, and research execution outcomes as ways to make later behavior better.

ReAP stores and retrieves a reflection from a prior web-navigation task. It turns a lesson such as a successful or failed navigation strategy into prompt guidance for another task.

For GUI agents, Mobile-Agent-E has an Action Reflector and a Notetaker. They evaluate executed steps and add practical Tips and Shortcuts to persistent memory. For research agents, Dolphin runs generated code, then uses exceptions and benchmark outcomes to revise its next idea or implementation.

The common rule is simple: an agent has not evolved merely because it produced a critique. An earlier outcome must leave a trace that changes a later decision. Transition: collective reasoning changes who performs the work within one task.

## 12. INFOGENT assigns three jobs to one web question.

**03 · Collaborating · 1:05 · cumulative 13:40–14:45 · 4 progressive reveals**

Section 6.5.3 shifts the question from learning across attempts to dividing work inside one attempt. INFOGENT is the clearest web example: it assigns navigation, evidence extraction, and aggregation to distinct roles.

Advance through the roles. The Navigator finds pages, the Extractor returns passages, and the Aggregator writes an answer from that evidence. This division matters because a fluent summary without supporting passages is not a useful research artifact.

The last stage is the important feedback path. When the Aggregator identifies an information gap, it sends the task back to navigation. The system therefore does not simply pass a document down a fixed assembly line.

Other systems use different role boundaries: WebPilot separates global planning from local MCTS executors, while GUI agents often separate planning, perception, action, reflection, and note taking. More agents also add coordination cost and can repeat the same error. Transition: trace the specific artifacts in an INFOGENT-style handoff.

## 13. A web-research team passes evidence, not just conclusions.

**03 · Collaborating · 1:00 · cumulative 14:45–15:45 · 4 progressive reveals**

This is an illustrative walkthrough, not a reported INFOGENT trajectory. It applies the role structure to the question we just discussed: which self-evolving systems reuse prior experience?

Advance through the handoffs. The Navigator produces a search set. The Extractor supplies the particular source passages. The Aggregator can then distinguish workflow memory, retrieved reflections, GUI tips, and execution feedback without treating them as one mechanism.

The final handoff is a gap report, not a vote. If the source does not support a claim, the right next action is to retrieve better evidence, not to ask another agent to restate the conclusion.

This is why interfaces matter in collective reasoning: the output of one role becomes a checkable input for the next. Transition: Agent Laboratory applies the same principle to literature, experiments, and writing.

## 14. A research assistant, organized as a lab.

**03 · Collaborating · 1:30 · cumulative 15:45–17:15 · 3 progressive reveals**

Agent Laboratory addresses the integration problem: a promising idea requires literature, executable experiments, interpretation, and a report. It takes a human-provided idea and notes, then runs three main phases. The academic role labels name prompted agent responsibilities, not human-equivalent qualifications.

Reveal experimentation. Planning and data preparation precede execution. The mle-solver proposes or edits programs, executes them, scores outcomes, reflects on errors or improvements, and retains strong candidate programs. Its score is a search signal; it is not itself proof of scientific validity.

Reveal report writing. The paper-solver turns the accumulated research into a report and iteratively refines it. Code, results, and interpretation persist across phases, which is why the survey names this system under memory in Section 6.5.2. Its specialized roles make it a useful supporting example for collaboration, even though the survey does not name it in Section 6.5.3.

Reveal human guidance. In co-pilot mode, a researcher can provide feedback at the end of each subtask. The paper studies different model backends and human evaluations rather than demonstrating unrestricted autonomous science. The output is a research-assistance artifact that needs inspection. Transition: the most revealing experiment asks who is judging the result.

## 15. A convincing report can fool its reviewer.

**03 · Collaborating · 1:20 · cumulative 17:15–18:35 · 2 progressive reveals**

The autonomous evaluation generated fifteen papers: five questions using three model backends. Ten volunteer PhD students each reviewed three randomly assigned papers. These are a small set of machine-learning research tasks, so we should not generalize the scores to all science.

Advance for the chart. Automated reviewers gave an average overall score of 6.1 out of ten, while human reviewers gave 3.8. A reviewer agent is therefore not automatically an independent quality guarantee. This is the main deeper insight from the paper: automating the evaluation loop can reward outputs that look better to models than to people.

Advance for co-pilot results. External evaluation gave co-pilot reports 4.38 versus 3.8 for autonomous reports. The paper reports improvements concentrated in quality, soundness, clarity, and presentation; significance slightly declined and contribution barely changed. The study is not a randomized isolation of the effect of human feedback, and backend and task differences matter.

The paper also documents hallucinated experiment details and failures in execution. Its cost reductions concern particular reported inference configurations, not the total cost of doing research. We have intentionally centered scientific quality rather than treating cheap report generation as discovery. Transition: combine the useful capabilities while retaining an evidence check at every layer.

## 16. Add capabilities. Keep the evidence loop.

**Synthesis · 0:55 · cumulative 18:35–19:30 · 2 progressive reveals**

This matrix depicts a cumulative system design, not a claim that every multi-agent system must have persistent memory. The survey dimensions can overlap. A collective system could coordinate specialists without evolving over time, and a single agent could learn reusable workflows.

Advance through the additions. Tool use expands what an agent can do. Persistent adaptation changes what it can carry into the next task. Coordination changes how specialized work is distributed. The foundational loop remains useful throughout.

Three takeaways follow from the evidence we examined. First, outcomes should be checked against the environment. Second, memory is only helpful when its procedures are applicable and trustworthy. Third, a reviewer must be evaluated too; agreement and fluent reports are insufficient evidence.

Close by returning to the central lesson: acting, learning, and collaborating can be combined, but each depends on evidence that the system actually achieved its goal.
